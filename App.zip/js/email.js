function inputTypeIsSupported(field) {
	return (field.type == "text");
}

var passedValidation = true;

var emailField = document.getElementById("emailField");
if (!inputTypeIsSupported(emailField)) {
   //call our fallback function
    passedValidation = validateEmail(emailField);
}